# Phase 5B B0 review — full validation run

**Assessment: inference completed on the entire frozen validation split. The primary score and S/D/I totals were independently recomputed and match all saved per-clip records.**

## Run coverage and integrity

- **732 of 732** unique frozen validation IDs have predictions; all 16 anonymous frozen components are represented.
- Saved references and membership were checked against the Phase 5A validation manifest; its SHA-256 is `91159654c31db4ca0721b3af1c43d44076e234c7fa2c95a8a2699d7acf3c6d7a`.
- Per-clip edit distance was independently recalculated for all 732 rows and matched the saved S/D/I totals.
- No test data was used. All 732 rows completed with status `ok`; there were no decode errors or empty outputs.

## Score and interpretation

- Reference denominator: **64,137 NFD code points** including spaces.
- Substitutions **36,780**, deletions **4,171**, insertions **25,193**; total **66,144** character edits.
- Corpus code-point CER: **1.0313 = 103.13%**. Lower CER is better. This score is high: there were slightly more edit operations than reference characters overall. It does not mean 103% of clips or words were wrong; CER is not bounded at 100%, because insertions can raise it above the reference length.
- Substitutions make up the largest share of edits (**55.6%**), followed by insertions (**38.1%**) and deletions (**6.3%**). This is a weak zero-shot transcription result, but a useful pre-fine-tuning baseline.

## Generation and runtime diagnostics

- **602 (82.2%)** sequences ended with EOS; **130 (17.8%)** reached the 448-token cap without EOS.
- **52 (7.1%)** outputs contain the replacement character U+FFFD. These outputs remain in the score.
- All 732 automatically selected prefix IDs `[50258, 50259, 50359]` (start, English, transcribe). Language and task were not forced. This observed English selection should be considered during error analysis; it does not justify inventing a Nyishi language token.
- Total per-sample time is **707.35 seconds** over **1.8818 audio hours**, an observed RTF of **0.1044** on the Tesla T4. The full pass processed the remaining 720 clips in **698.56 seconds**, with peak memory **446.9 MiB allocated / 482.3 MiB reserved**.

## Reporting issue found and corrected here

The original Kaggle ZIP says `status: complete` and its corpus CER/edit totals agree with the predictions, but its saved plots still have titles saying **12 clips** and show the preflight only. Its mean per-sample runtime (**0.9308 s**) and last-pass timing/memory fields also refer to the preflight; the actual full-set mean is **0.9663 s**, and the full-pass telemetry is recorded in `inference_passes.jsonl`. The corrected aggregate and four full-set plots are in this review folder. Do not use the original plots or those stale timing/memory fields in a report.

## What the result says

The baseline run is complete as a **measurement of the declared zero-shot setup**, but the model's transcription quality is poor on this validation set. The 130 cap hits have a descriptively much higher CER than uncapped clips; this is a signal to inspect those outputs, not proof that the cap alone caused the errors. The component and duration plots are descriptive and do not identify causes.

## Next steps

1. Keep this B0 checkpoint, split, text policy, and run configuration fixed as the reference; keep the test split sealed.
2. Review a manageable sample of high-CER, capped, U+FFFD, and low-CER outputs against their audio and references. Classify errors (reference issue, IPA substitution/mark, omitted material, extra/repeated output, or possible truncation). Do not rewrite labels or drop clips just to improve CER.
3. Record that the model automatically selected English for all clips. Before any learning run, decide and document the training/generation prefix policy without inventing a Nyishi token.
4. Proceed to Phase 6A supervised-training smoke only after that prefix/label-shift policy is explicit: finite FP16-AMP loss and gradients, a real optimizer update, and checkpoint resume. Then run the planned small training pilot and compare validation CER against this 103.13% B0 score.
5. Re-run the Phase 5B reporting/plot cell and save cell in Kaggle if you want the Kaggle ZIP itself to contain updated full-set plots. This review folder already contains recomputed full-set plots and corrected metrics without another model run.

**Bottom line:** B0 inference is complete; the original result ZIP's score is valid, but its plots and some runtime/memory summary fields are stale preflight artifacts. Use the corrected review files for interpretation.
